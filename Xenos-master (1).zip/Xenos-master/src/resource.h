//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Xenos.rc
//
#define IDC_MYICON                      2
#define IDD_WIN32_TEMPLATE_DIALOG       102
#define IDM_ABOUT                       104
#define IDR_MAINFRAME                   128
#define IDD_MAIN                        129
#define IDI_ICON1                       135
#define IDD_MODULES                     137
#define IDR_MENU_MAIN                   138
#define IDD_WAIT_PROC                   139
#define IDD_SETTINGS                    140
#define IDR_ACCELERATOR1                141
#define IDR_DRV7                        142
#define IDR_DRV8                        147
#define IDR_DRV81                       149
#define IDR_DRIVER1                     150
#define IDR_DRV10                       150
#define IDC_EDIT_MAIN                   1000
#define IDC_EXECUTE                     1001
#define IDC_COMBO_PROC                  1002
#define IDC_INIT_EXPORT                 1003
#define IDC_LOAD_IMG                    1004
#define IDC_IMAGE_PATH                  1005
#define IDC_THREADS                     1006
#define IDC_OP_TYPE                     1007
#define IDC_LDR_REF                     1008
#define IDC_MANUAL_IMP                  1009
#define IDC_WIPE_HDR                    1010
#define IDC_ARGUMENT                    1011
#define IDC_IGNORE_TLS                  1012
#define IDC_NOEXCEPT                    1013
#define IDC_BUTTON_UNLOAD               1013
#define IDC_UNLINK                      1014
#define IDC_BUTTON_CLOSE                1014
#define IDC_LOAD_IMG2                   1015
#define IDC_NEW_PROC                    1015
#define IDC_LIST_MODULES                1015
#define IDC_HIJACK                      1015
#define IDC_CMDLINE                     1016
#define IDC_WAIT_BAR                    1016
#define IDC_HIDEVAD                     1017
#define IDC_WAIT_TEXT                   1017
#define IDC_INJ_CLOSE                   1018
#define ID_WAIT_CANCEL                  1018
#define IDC_EXISTING_PROC               1019
#define IDC_INJ_EVERY                   1019
#define IDC_INJ_EACH                    1019
#define IDC_SELECT_PROC                 1020
#define IDC_AUTO_PROC                   1021
#define ID_SETTINGS_CANCEL              1021
#define ID_SETTINGS_OK                  1022
#define IDC_SETTINGS                    1023
#define IDC_WIPE_HDR_NATIVE             1024
#define IDC_MODS                        1025
#define IDC_ADD_MOD                     1026
#define IDC_REMOVE_MOD                  1027
#define IDC_CLEAR_MODS                  1028
#define IDC_DELAY                       1029
#define IDC_PERIOD                      1030
#define IDC_CHECK1                      1031
#define IDC_KRN_HANDLE                  1031
#define IDC_SKIP                        1032
#define ID_TOOLS_EJECTMODULES           32772
#define ID_TOOLS_PROTECTSELF            32773
#define ID_TOOLS_PROTECT                32774
#define ID_PROFILES_OPEN                32775
#define ID_PROFILES_SAVE                32776
#define ID_ACCEL_SAVE                   32777
#define ID_ACCEL_OPEN                   32778
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        151
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
